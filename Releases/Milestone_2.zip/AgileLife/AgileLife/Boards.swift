//
//  Boards.swift
//  AgileLife
//
//  Created by Zachary Gover on 4/18/16.
//  Copyright © 2016 Full Sail University. All rights reserved.
//

import Foundation
import CoreData


class Boards: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
