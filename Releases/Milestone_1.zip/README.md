README
==================
*******************************

**Author:** Zachary Gover <br>
**Current Stable Version:** 1.0.0 <br>
**Bitbucket Repository:** [https://bitbucket.org/Zachary1748/agile-life](https://bitbucket.org/Zachary1748/agile-life)
**Available Features:**
	- hello