//
//  BLSideMenuTableFooter.swift
//  AgileLife
//
//  Created by Zachary Gover on 4/14/16.
//  Copyright © 2016 Full Sail University. All rights reserved.
//

import UIKit

class BLSideMenuTableFooter: UITableViewHeaderFooterView {

    @IBAction func viewHistory(sender: UIButton) {
        
    }

}
